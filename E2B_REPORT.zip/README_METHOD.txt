E2B Repeated Stratified Group Cross-Validation

Four candidates selected from exploratory E2.
Three repeats, five folds per repeat.
Fraud F1 is the primary metric.
Decision threshold fixed at 0.5.

The original E2 development/holdout group split
is reconstructed and verified.

Outer fold seeds differ across repeats.
Inner fit/calibration split is group-aware.
Preprocessing fits on training-fit only.
AutoEncoder trains only on normal fit samples.
SMOTE applies only to classifier training-fit.
Calibration and validation are never oversampled.

The historical holdout remains unevaluated.
This is a robustness study on development data,
not a fully independent confirmatory test.

Because repeats reuse development observations,
do not treat all 15 folds as independent test
datasets when constructing confidence intervals.