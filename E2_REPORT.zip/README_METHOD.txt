E2 — Feature Representation x SMOTE Ablation Study

Primary metric: Fraud F1 at threshold 0.5.
Secondary: Average Precision, precision, recall,
MCC, ROC-AUC, and false positives.

Representation: Original29 vs Hybrid94.
SMOTE: None, .10, .25, .50, 1.00.
Classifiers: CatBoost, ExtraTrees, RF, LightGBM.

Group-safe splitting is used based on the 29
predictor columns, excluding Time.

SMOTE and preprocessing fitting are restricted
to the fit subset. AutoEncoder training uses
only legitimate transactions from fit.

Calibration and outer validation remain untouched.

The historical dataset was previously inspected.
The nominal holdout is not evaluated in E2.

E2 has a different splitting protocol from E1.
Do not directly interpret differences between
their metrics as method improvements.

Repeated CV and independent confirmation
are separate later stages.