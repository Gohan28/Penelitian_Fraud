E1C Threshold Policy Sensitivity Analysis

Input: saved E1 five-fold classifier probabilities.
No AE training, classifier fitting, or SMOTE.

T0: fixed threshold 0.5
T1: max calibration F1, recall >= 85%
T2: max calibration F1, no recall constraint
T3: maximize calibration recall subject to
    FP <= 0.5 per 1000 legitimate transactions;
    ties prefer fewer FP then higher threshold.

All thresholds selected using calibration labels only.
Outer validation used for evaluation only.
E1 T0/T1 confusion matrices are checked for consistency.

Research caveat:
T2/T3 were formulated after inspecting E1.
Results are exploratory and not an independent
confirmatory test.
Previously inspected historical holdout is not evaluated.

Do not declare the top outer-CV policy an independently
validated winner without an appropriate confirmation design.